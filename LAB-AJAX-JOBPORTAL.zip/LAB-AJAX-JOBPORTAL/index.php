<?php 

header('Location: view/jportADMIN.html');

?>